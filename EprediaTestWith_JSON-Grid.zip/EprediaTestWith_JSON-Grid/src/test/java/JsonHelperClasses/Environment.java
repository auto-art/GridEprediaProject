package JsonHelperClasses;

public class Environment {
		
	public String appurl;
	public String browser;
	public String Gid;
	public String password;
	public String loginmethod;
	
	public String getFid() {
		return Fid;
	}
	public void setFid(String fid) {
		Fid = fid;
	}
	public String getFpassword() {
		return Fpassword;
	}
	public void setFpassword(String fpassword) {
		Fpassword = fpassword;
	}
	public String Fid;
	public String Fpassword;
	
	public String getGid() {
		return Gid;
	}
	public void setGid(String gid) {
		Gid = gid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAppurl() {
		return appurl;
	}
	public void setAppurl(String appurl) {
		this.appurl = appurl;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	
	public String getLoginMethod() {
		return loginmethod;
	}
	
}
