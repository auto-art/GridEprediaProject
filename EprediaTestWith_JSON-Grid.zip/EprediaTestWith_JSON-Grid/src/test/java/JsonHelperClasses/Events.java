package JsonHelperClasses;

public class Events {
	
	public String deviceid;
	public String event_type;
	public String description;
	public String commercial_region;
	public String service_region;
	public String error_code;
	public String timestamp;
	public String getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getEvent_type() {
		return event_type;
	}
	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCommercial_region() {
		return commercial_region;
	}
	public void setCommercial_region(String commercial_region) {
		this.commercial_region = commercial_region;
	}
	public String getService_region() {
		return service_region;
	}
	public void setService_region(String service_region) {
		this.service_region = service_region;
	}
	public String getError_code() {
		return error_code;
	}
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	

}
