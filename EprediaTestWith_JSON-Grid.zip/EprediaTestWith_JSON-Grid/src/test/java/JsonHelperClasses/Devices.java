package JsonHelperClasses;

public class  Devices {	
	
		public String deviceid;
		public String deviceName;
		public String serialNumber;
		public String software;
		public String firmware;
		public String status;
		public String requestType;
		public String chamberStatus;
		public String protocolName;
		public String reagentName;
		public String timestamp;
		
		
		public String getDeviceid() {
			return deviceid;
		}
		public void setDeviceid(String deviceid) {
			this.deviceid = deviceid;
		}
		public String getDeviceName() {
			return deviceName;
		}
		public void setDeviceName(String deviceName) {
			this.deviceName = deviceName;
		}
		public String getSerialNumber() {
			return serialNumber;
		}
		public void setSerialNumber(String serialNumber) {
			this.serialNumber = serialNumber;
		}
		public String getSoftware() {
			return software;
		}
		public void setSoftware(String software) {
			this.software = software;
		}
		public String getFirmware() {
			return firmware;
		}
		public void setFirmware(String firmware) {
			this.firmware = firmware;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getRequestType() {
			return requestType;
		}
		public void setRequestType(String requestType) {
			this.requestType = requestType;
		}
		public String getChamberStatus() {
			return chamberStatus;
		}
		public void setChamberStatus(String chamberStatus) {
			this.chamberStatus = chamberStatus;
		}
		public String getProtocolName() {
			return protocolName;
		}
		public void setProtocolName(String protocolName) {
			this.protocolName = protocolName;
		}
		public String getReagentName() {
			return reagentName;
		}
		public void setReagentName(String reagentName) {
			this.reagentName = reagentName;
		}
		public String getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}
		

}
