package JsonHelperClasses;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.json.simple.parser.ParseException;
import gherkin.deps.com.google.gson.Gson;

public class JsonDataReader {

	private List<Devices> deviceList;
	
	public JsonDataReader() throws FileNotFoundException, IOException, ParseException{
		
		
	}
		
	// Java program to read JSON from a file
	public  List<Devices> readJSONData() throws FileNotFoundException, IOException, ParseException  { 
	
		 final String devjsonFilePath="resources/testdata/Devices.json";
		
			Gson gson = new Gson();
			BufferedReader bufferReader = null;
			try {
				bufferReader = new BufferedReader(new FileReader(devjsonFilePath));
				Devices[] deviceobj = gson.fromJson(bufferReader, Devices[].class);
				return Arrays.asList(deviceobj);
			}
			catch(FileNotFoundException e) {
				throw new RuntimeException("Json file not found at path : " + devjsonFilePath);
			}
			finally {
				try { if(bufferReader != null) 
					bufferReader.close();}
				catch (IOException ignore) {}
			}			
		}
	
	
	public  List<Events> readEventJSONData() throws FileNotFoundException, IOException, ParseException  { 
		
		 final String devjsonFilePath="resources/testdata/Events.json";
		
			Gson gson = new Gson();
			BufferedReader bufferReader = null;
			try {
				bufferReader = new BufferedReader(new FileReader(devjsonFilePath));
				Events[] eventobj = gson.fromJson(bufferReader, Events[].class);
				return Arrays.asList(eventobj);
			}
			
			catch(FileNotFoundException e) {
				throw new RuntimeException("Json file not found at path : " + devjsonFilePath);
			}
			finally {
				try { if(bufferReader != null) 
					bufferReader.close();}
				catch (IOException ignore) {}
			}			
		}
	
	
	public  Environment readEnvJSONfile() throws FileNotFoundException, IOException, ParseException  {
			
			final String envjsonFilePath="resources/testdata/Environment.json";		
			
			Gson gson = new Gson();
			BufferedReader bufferReader = null;
			try {
				bufferReader = new BufferedReader(new FileReader(envjsonFilePath));
				Environment envobj = gson.fromJson(bufferReader, Environment.class);
				return envobj; 
			}
			catch(FileNotFoundException e) {
				throw new RuntimeException("Json file not found at path : " + envjsonFilePath);
			}
			finally {
				try { if(bufferReader != null) 
					bufferReader.close();}
				catch (IOException ignore) {}
			}
		}
		
}

	
 