package com.epredia.StepDefinition;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import com.epredia.Common.TestBase;
import com.epredia.Pages.DeviceDetails;
import com.epredia.Pages.Login;
import com.epredia.TestRunner.TestGridRunner;

import JsonHelperClasses.JsonDataReader;

public class LoginStepDef extends TestGridRunner {
	
	Login login=new Login();
	TestBase testbase=new TestBase();
	DeviceDetails devicedetails;
	public RemoteWebDriver driver = this.remotedriver;

	@Given("^User launch EprediaRevos application in Jsongiven browser$")				
    public void User_launch_EprediaRevos_application_in_browser() throws Throwable	  {		
        System.out.println("Launched Epredia application....");          
       // login.launchbrowser();
        testbase. readPropertyFile();
    }	
    
    @And("^User clicks on Login button$")				
    public void User_clicks_on_Login_button() {
    	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/p[2]/button")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    }
        
    @And("^User selects loginmethod to login$")				
    public void User_selects_Googleoption_for_login() {    	
    	login.loginMethod();
       }
        
    @And("^User enters username and password$") 
    public void User_enters_username_and_password() {
    try {
    	String logintype=null;
       	JsonDataReader jreader=new JsonDataReader();    	
    	logintype=jreader.readEnvJSONfile().getLoginMethod();
    	if(logintype.equals("Google")) {
    	String username=jreader.readEnvJSONfile().getGid();
        String password=jreader.readEnvJSONfile().getPassword();        
    	devicedetails=login.loginByGoogle(username,password);  
    	}else {
    	String username=jreader.readEnvJSONfile().getFid();
        String password=jreader.readEnvJSONfile().getFpassword();
    	devicedetails=login.loginByFacebook(username,password);   	
    	}    	
    } catch(Exception e) {
    		e.printStackTrace();  }
    }
    
    @Then("^User successfully login to application$")
    public void User_successfully_login() throws InterruptedException {     	
    	//driver.findElement(By.name("__CONFIRM__")).click();    	
    	System.out.println(" Login successful ");	
    	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);    	    	
    	
    }
    
    @When("User enters incorrect loginid and password")
    public void user_enters_incorrect_loginid_and_password() {        
    	String Username="laxmi@1234";
    	String paswd="1234";
    	login.invalidLogin(Username,paswd);         
    }

    @Then("User validate invalid login message")
    public void user_validate_invalid_login_message() {
    	String errormsg=driver.findElement(By.className("o6cuMc")).getText();
    	Assert.assertEquals("Enter a valid email or phone number", errormsg);
    	
    }


    
}
