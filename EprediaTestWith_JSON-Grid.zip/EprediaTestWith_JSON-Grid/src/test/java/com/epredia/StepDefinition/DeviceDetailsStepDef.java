package com.epredia.StepDefinition;

import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.epredia.Pages.DeviceDetails;
import com.epredia.TestRunner.TestGridRunner;
import com.epredia.Common.TestBase;
import JsonHelperClasses.Devices;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;		
import io.cucumber.java.en.When;

public class DeviceDetailsStepDef extends TestGridRunner {
    
	public RemoteWebDriver driver = this.remotedriver;
	
		Devices deviceobject;
		DeviceDetails devicedetails= new DeviceDetails();		
		
    @When("User clicks on the device name as input from Json")
    public void user_clicks_on_the_device_name()  throws Throwable  {	
    	//System.out.println(deviceindex);
    	devicedetails.clickDeviceUsingJson(TestBase.deviceindex);	
    }        
    
    @Then("^User validate that device details section is displayed$")					
    public void User_validate_that_device_details_are_displayed() throws Throwable  {    		
    	WebElement devicetable=driver.findElement(By.xpath("/html/body/app-root/app-main/div/div[1]/div[2]/div/div[1]/app-device-details/div/div"));    	
    	if(devicetable!=null) {
    	System.out.println(" Device information ----->");}				
    }     
    
    @Then("^User validate the devicedata using jsoninput$")
    public void User_validate_the_devicedata_using_jsoninput() throws Exception {      			
    	
    	devicedetails.verifyDeviceDataUsingJson(TestBase.deviceindex);     	
    	System.out.println(" Device Details validated ");   
    }      
    
    @Then("^User validate device serial number$")				
    public void User_validate_device_serial_number() throws Throwable  {
    	
    	devicedetails.validateSerialNumberUsingJson();
    	System.out.println(" Device serial number validated");				
    }
    
    @Then("^User validate the Events section$")
    public void  User_validate_the_Events_section() throws Throwable {
    	devicedetails.verifyEvents(TestBase.deviceindex);
    	System.out.println(" Event section validated");	
    }
       
    @And("^User view different tabs present in homepage$")
    public void  User_view_different_tabs_present_in_homepage() throws Throwable {
    	devicedetails.validateTabsinhomepage();    	
    	System.out.println(" Different tabs validated ");	
    }
    
    @When("User refresh the devices homepage in browser")
    public void user_refresh_the_devices_homepage_in_browser() {  
    	
    	devicedetails.validatePageRefresh();
    }
    
    
    @Then("User lands in the homepage again")
    public void user_lands_in_the_homepage_again() {
    	
        System.out.println("Page refreshed to homepage");        
    }    
    
    @Then("User validates app status as green")
    public void user_validates_app_status_as_green() {
            WebElement greendots= driver.findElement(By.cssSelector(".form-inline"));            
            Assert.assertNotNull(greendots);

    }

    
    /*----------------Negative Scenarios--------------------------------------------     */
    
    @Then("User validate Events not available")
    public void user_validate_Events_not_available() throws Exception  {
    	devicedetails.verifyNoEventsdata();
    	System.out.println(" No Events ");	
    	
    }
    
    @Then("User validate test failure with serialnumber mismatch message")
    public void user_validate_test_failure_with_serialnumber_mismatch_message() throws ParseException {
    	devicedetails.invalidSerialNumber();
    }
    
    @When("User enters wrong devicename and validate the error message")
    public void user_enters_wrong_devicename_and_check_error() throws IOException, ParseException {
    	devicedetails.clickDeviceUsingJson(TestBase.deviceindex);
    	System.out.println("Please check -device name incorrect");
    }

   
    
    @And("^User close the browser$")
    public void User_close_the_browser()  {    	    	
    	
    	
    	
    }
    
}
