package com.epredia.Common;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.epredia.TestRunner.TestGridRunner;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import com.epredia.Common.*;

public class Hooks extends TestGridRunner {
	
	Logger log=Logger.getLogger(Hooks.class);
	private int counter1=0;
	private int counter2=0;
	private RemoteWebDriver driver = this.remotedriver;
	
	@Before
	public void setup() throws IOException {			
		
		try {			
			log.info("Device json index"+ counter1);
			log.info("Events json index"+ counter2);
			TestBase.getIndexforDeviceJson(counter1);
			TestBase.getIndexforEventJson(counter2);
		} catch (Exception e) {			
			e.printStackTrace();	}		
	}
	
	
	/**
	 * <p>
	 * Takes screen-shot if the scenario fails
	 */
	

	@After()
	public void afterTest(Scenario scenario) throws InterruptedException {
		
	    log.info("Taking screenshot IF Test Failed");
	    System.out.println("Taking screenshot IF Test Failed (sysOut)");
	    if (scenario.isFailed()) {
	        try {
	            log.info(scenario.getName() + " is Fail ");	           
	            final byte[] screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	           scenario.embed(screenShot, "image/png");
	            	            
	        } catch (WebDriverException e) {
	            log.error(e.getMessage()); 
	            driver.close(); }
	    }		    
	    try {
	    	counter1=TestBase.incrementIndexforDeviceJson();
	    	counter2=TestBase.incrementIndexforEventJson();    	
	    	
		} catch (Exception e) {
			e.printStackTrace();
			}
	    
	    //driver.close();
	    
	}
	
	
	
}
