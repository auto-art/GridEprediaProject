package com.epredia.Common;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.epredia.Common.*;

import JsonHelperClasses.Devices;
import JsonHelperClasses.Events;
import JsonHelperClasses.JsonDataReader;
import io.cucumber.testng.TestNGCucumberRunner;


//This includes all the webdriver driver settings and global objects , browser	

public  class TestBase  {

	public  static WebDriver driver;
	public  static String filename;		
	String  url;
	static String  driverPath;
	String browsername;
	String PROPERTIES_FILE_PATH= "com/epredia/util/config.properties";
	protected static String Gusername;
	protected static String Gpassword;
	public static int deviceindex=0;
	public  static int eventindex=0;

	private TestNGCucumberRunner testNGCucumberRunner;
	protected RemoteWebDriver remotedriver;

	@BeforeClass(alwaysRun = true)
	public void setUpCucumber() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	//static Logger log=(Logger) LoggerFactory.getLogger(TestBase.class);

	Helper helper;	

	public   void readPropertyFile()  {		
		try {			
			InputStream inputstream = getClass().getClassLoader().getResourceAsStream(PROPERTIES_FILE_PATH);					
			try {	
				Properties prop = new Properties(); // reading config.properties	
				// load the properties
				prop.load(inputstream);	
				driverPath = prop.getProperty("driverpath");
			} 	 catch (Exception e) {
				System.out.println("File not loaded");
			}			 	   
			if(driverPath!= null) {
				System.out.println(driverPath);	}
			else {
				System.out.println("driverPath not specified in the Configuration.properties file.");  	}
		}  catch (Exception e) {			 	
			System.out.println("Configuration.properties not found at " + PROPERTIES_FILE_PATH);	 	} 		
	}


	/*@BeforeMethod(alwaysRun = true)
	@Parameters(value = { "browser", "version" })		
	//setting up browser for execution	
	public static void setupbrowser(String browsername,String version) throws IOException,InterruptedException, MalformedURLException {	

		String baseURL="http://localhost:4200/login";

		String gridURL = "http://192.168.1.10:4444/wd/hub";
		System.out.println(gridURL);
		DesiredCapabilities capability = new DesiredCapabilities();	  
		capability.setCapability(CapabilityType.BROWSER_NAME, browsername);
		capability.setCapability(CapabilityType.VERSION,version);
		capability.setCapability("build", "Test Epredia App");	    		
			
			driver = new RemoteWebDriver(new URL(gridURL), capability);
			System.out.println(capability); 
			
			if(browsername.equalsIgnoreCase("Chrome")) {	    
				String chromedriver = driverPath + "/chromedriver.exe";
				System.out.println(chromedriver);
				System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
				driver= new ChromeDriver();		   }	    

			if(browsername.equalsIgnoreCase("InteretExplorer"))  {
				String IEdriver = driverPath +"/IEDriverServer.exe";
				System.out.println(IEdriver);
				System.setProperty("webdriver.ie.driver", "drivers/IEdriverserver.exe");
				driver= new InternetExplorerDriver(); }

			if(browsername.equalsIgnoreCase("Firefox")) {

				String FFdriver = driverPath +"/geckodriver.exe";
				System.out.println(FFdriver);
				System.setProperty("webdriver.gecko.driver", "drivers/geckodriver.exe");
				driver= new FirefoxDriver();   }	    
		
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.navigate().to(baseURL);	 
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS); 	   
		}
		*/

		public static void getIndexforDeviceJson(int deviceindexlocal) throws Exception {

			deviceindex=deviceindexlocal;
			JsonDataReader jsonreader=new JsonDataReader();
			List<Devices> devicelist=jsonreader.readJSONData();       	
			if(deviceindex<= devicelist.size()-1) {
				System.out.println("counter : " + deviceindex );	
			}					
		}

		public static int incrementIndexforDeviceJson() throws Exception {			
			JsonDataReader jsonreader=new JsonDataReader();
			List<Devices> devicelist=jsonreader.readJSONData();  
			if(deviceindex<= devicelist.size()-1) {	    		
				deviceindex=deviceindex+1;    
				System.out.println("counter Incremented  to: " + deviceindex );
			}	
			return deviceindex;
		}

		public static void getIndexforEventJson(int eventindex) throws Exception {

			JsonDataReader jsonreader=new JsonDataReader();
			List<Events> eventslist=jsonreader.readEventJSONData();  

			if(eventindex<= eventslist.size()-1) {    	    			
				System.out.println("counter" + eventindex );    	}					
		}


		public static int incrementIndexforEventJson() throws Exception {

			JsonDataReader jsonreader=new JsonDataReader();
			List<Events> eventlist=jsonreader.readEventJSONData(); 		    	
			if(eventindex< eventlist.size()-1) {	    		
				eventindex=eventindex+1;    
				System.out.println("counter Incremented  to: " + eventindex );
			}
			return eventindex;
		}

		public WebDriver getDriver() {
			return driver;
		}	


		public void afterTestteardown() {
			driver.quit();
		}

}
