package com.epredia.Common;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.rules.Timeout;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Helper extends TestBase {

	
	// methods for selenium helpers like click element by id, ;
	
	
	public  void findElementById(String id) {
		WebElement element= driver.findElement(By.id("id"));
		element.click();		
	}
	
	public void findElementByxpath(String xpath) {
		WebElement element= driver.findElement(By.id("xpath"));
		element.click();		
	}
	
	public void clickelement(WebElement element) {
		
		element.click();		
	}
		
	public void clickElementUsingJavascript(WebElement element) {
		
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("argument[0].click()",element);		
	}
	
	public void waitForSeconds() {
			
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
		
	public void waitforElement( WebElement element) {			
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			element = wait.until(ExpectedConditions.elementToBeClickable(element));
			element.click();
			
		}
	
}
