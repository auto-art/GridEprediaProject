package com.epredia.Pages;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.epredia.Common.TestBase;

import JsonHelperClasses.JsonDataReader;

public class Login extends TestBase {

	/*Properties prop;
	
	String gmailid=prop.getProperty("username");
	String password=prop.getProperty("password");
	*/
	
	//Initialize
	public Login() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="#identifierId") WebElement userid;
	@FindBy(css="#identifierNext > span > span") WebElement Nextbtn;
	@FindBy(css=".I0VJ4d > div:nth-child(1) > input:nth-child(1)") WebElement password;
	//@FindBy(name="password") WebElement password;
	@FindBy(css=".I0VJ4d > div:nth-child(1) > input:nth-child(1)") WebElement googleoption;
	@FindBy(xpath="//span[contains(text(),'Next')]") WebElement paswdnextbtn;
	@FindBy(xpath="/html/body/app-root/app-login/div/div/p[2]/button") WebElement Loginbtn;
	
	public void launchbrowser() throws Exception {		
		
		JsonDataReader jsonreader= new JsonDataReader();
	    String browsernamefromJson=jsonreader.readEnvJSONfile().getBrowser();
	    String urlfromJson=jsonreader.readEnvJSONfile().getAppurl();			    
		//TestBase.setupbrowser(browsernamefromJson,urlfromJson); 
	}
	
	
	public void userlogin() {		
		
		WebDriverWait wait = new WebDriverWait(driver, 60);
		String title=driver.findElement(By.cssSelector(".card > h4:nth-child(2)")).getText();			
		wait.until(ExpectedConditions.elementToBeClickable(Loginbtn));
		Loginbtn.click();			
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		loginMethod();		
		userid.sendKeys(Gusername);   		
		Nextbtn.click();		
		wait.until(ExpectedConditions.elementToBeClickable(password));
		Actions builder=new Actions(driver);
		builder.moveToElement(password).click();			
		password.sendKeys(Gpassword);  		
		wait.until(ExpectedConditions.elementToBeClickable(paswdnextbtn));
		paswdnextbtn.click();
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	System.out.println(" Login successful ");	
    	
	}
	
	public void loginMethod() {
		try {			
			JsonDataReader jreader=new JsonDataReader();
			String loginmethod=jreader.readEnvJSONfile().getLoginMethod();				
			JavascriptExecutor js=(JavascriptExecutor) driver;			
			WebElement loginoption;
			if(loginmethod.equals("Google")) {
			loginoption= driver.findElement(By.id("GoogleExchange")); }
			else {
	    	loginoption= driver.findElement(By.id("FacebookExchange")); }
			js.executeScript("arguments[0].scrollIntoView(true);",loginoption);
			js.executeScript("arguments[0].click()", loginoption);}  	
			catch(Exception e) {
			e.getMessage(); }			
	}
	
	public DeviceDetails loginByFacebook(String Fusername, String Fpassword ) {
		
		driver.findElement(By.id("email")).sendKeys(Fusername);
    	driver.findElement(By.id("pass")).sendKeys(Fpassword);
    	driver.findElement(By.id("loginbutton")).click();    	
		return new DeviceDetails();		
	}
	
public DeviceDetails loginByGoogle(String Gusername, String Gpassword ) {
	try {
		
    	driver.findElement(By.cssSelector("#identifierId")).sendKeys(Gusername);   		
		driver.findElement(By.cssSelector("#identifierNext > span > span")).click();  //Nextbtn	
			
	/*	WebDriverWait wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions.elementToBeClickable(password));*/
		Actions builder=new Actions(driver);			
		builder.click(password);
		/* JavascriptExecutor jse = ((JavascriptExecutor)driver);
		 jse.executeScript("arguments[0].click();",password );*/
		
		 password.sendKeys(Gpassword);
		builder.moveToElement(paswdnextbtn).click();			
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	} catch (Exception e) {			
			e.printStackTrace();
	}
		return new DeviceDetails();	
	}
	
	public void invalidLogin(String Username,String paswd) {		
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);		
			wait.until(ExpectedConditions.elementToBeClickable(Loginbtn));
			Loginbtn.click();
			driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor) driver;			
			js.executeScript("arguments[0].scrollIntoView(true);",googleoption);
			js.executeScript("arguments[0].click()", googleoption);	
			userid.sendKeys(Username);
		}
			catch(Exception e) {
				System.out.println("Invalid Login-Entered username is incorrect");
			}
	}	
}
