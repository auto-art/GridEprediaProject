package com.epredia.Pages;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.epredia.Common.*;


import JsonHelperClasses.Devices;
import JsonHelperClasses.Events;
import JsonHelperClasses.JsonDataReader;

public class DeviceDetails extends TestBase {

	Helper helper;

	// Device section
	@FindBy(className = "navbar-brand")
	WebElement title;
	@FindBy(xpath = "/html/body/app-root/app-main/div/div[1]/div[2]/div/div[1]/app-device-details/div/div/div[3]")
	WebElement serialNumber;
	String Dtablexpath = "//*[@id=\"deviceDetails\"]/div/div";
	@FindBy(xpath="/html/body/app-root/app-main/nav/div/ul/li[1]") WebElement listofTabs;
	@FindBy(xpath="//a[contains(text(),'Manage users')]") WebElement ManageUserslink;
	@FindBy(xpath="//a[contains(text(),'More info')]") WebElement MoreInfolink;
	@FindBy(xpath="//a[contains(text(),'Disconnect')]") WebElement Disconnectlink;
	@FindBy(xpath="//a[contains(text(),'Make favourite')]") WebElement MakeFavlink;
	@FindBy(xpath="//a[contains(text(),'Schedule Instrument')]") WebElement ScheduleInstrumentlink;
	@FindBy(xpath="//a[contains(text(),'Change Language')]") WebElement languagelink;
	
	// Events section
	@FindBy(xpath = "//*[@id=\"home\"]/app-device-events/div/div")	WebElement textforNoEvent;
	@FindBy(xpath = "//*[@id=\"home\"]/app-device-events/table")	WebElement EventsTable;
	@FindBy(id = "home-tab") WebElement EventsTab;
	// *[@id="home"]/app-device-events/table/thead/tr/th[1]---event type

	//Initialize
	public DeviceDetails() {
		PageFactory.initElements(driver, this);
	}
	
	public void validatePageRefresh() {
		
		WebDriverWait wait = new WebDriverWait(driver, 140);		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Epredia Revos")));
		String heading1= driver.getCurrentUrl();
    	System.out.println("URL: " + heading1);
    	driver.navigate().refresh();
    	String heading2= driver.getCurrentUrl();
    	Assert.assertEquals(heading1, heading2);
	}

	public void clickDeviceonLHS(String dname) throws IOException {
		try {
			Thread.sleep(1000);
			System.out.println("Device name----->" + dname);
			//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 140);		
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='" +"Device Name :" + dname + " ']")));	
			WebElement device = driver.findElement(By.xpath("//div[text()='" +"Device Name :" + dname + " ']"));
			device.click();
			/*Actions action = new Actions(driver);
			action.moveToElement(device).click();*/
		} catch (InterruptedException e) {
			System.out.println("Device not found");
		}
		//getscreenshot();
	}
	
	public void clickDeviceUsingJson(int index) throws IOException, ParseException {
		
		try {
			Thread.sleep(5000);
			JsonDataReader jsonreader=new JsonDataReader();	    	
	    	List<Devices> devicelist=jsonreader.readJSONData();    	
	    	String deviceNameFromJson= devicelist.get(index).getDeviceName(); 	    	
			//System.out.println("Device name----->" + deviceNameFromJson);
			//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			Thread.sleep(5000);
			
			String xpath="//div[contains(text(),'Device Name :"+deviceNameFromJson+"')]";
			//String xpath="//div[contains(text(),'Device Name :RS0000000777 ')]";
			WebElement device = driver.findElement(By.xpath(xpath));
			WebDriverWait wait = new WebDriverWait(driver, 60);	
			wait.until(ExpectedConditions.elementToBeClickable(device));
            /*JavascriptExecutor jse = ((JavascriptExecutor)driver);
			jse.executeScript("arguments[0].scrollIntoView(true);",By.xpath(xpath));*/         
			device.click();	
			String Uivalue= StringUtils.substringAfterLast(device.getText(), ":").trim();
			Assert.assertEquals(deviceNameFromJson, Uivalue);
			
		} catch (Exception e) {
			e.getMessage();
		}
		
	}
	
	
	// This method fetches and validates the device data from UI
	public void verifyDeviceDataUsingJson(int jsondataindex) throws FileNotFoundException, IOException, ParseException {
				
		try {
			WebDriverWait wait = new WebDriverWait(driver, 40);		
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Dtablexpath)));		
			Thread.sleep(40);		 
			JsonDataReader jsonreader=new JsonDataReader();				
			List<Devices> devicelist=jsonreader.readJSONData();
			int i=jsondataindex;
			for(i=0; i< devicelist.size(); i++) {							
			List<WebElement> Devicetable = driver.findElements(By.xpath(Dtablexpath));	
			String[] msginfo = { "Device id", "Device Name", "Serial Number", "Software Version", "Firmware Version","Status" };				
			
			System.out.println(i);
				String[] deviceinfo = { devicelist.get(i).getDeviceid(), devicelist.get(i).getDeviceName(),devicelist.get(i).getSerialNumber(),devicelist.get(i).getFirmware(),devicelist.get(i).getSoftware(), devicelist.get(i).getStatus()};			
				
				for (int j = 0; j <= Devicetable.size() - 1; j++) {					
					String devicecols=Devicetable.get(j).getText();
					String UIvalue=(StringUtils.substringAfterLast(devicecols, ":")).trim();
					System.out.println();
					if (UIvalue.equals(deviceinfo[j])) {	
						System.out.println("  "+msginfo[j] + " verified");} 
					else {
						System.out.println("  "+msginfo[j] + " mismatch"); }
					}			
				
				if(i>0) {
					clickDeviceUsingJson(i);
				}
			}	 
		}
				catch (InterruptedException e) {			
					e.printStackTrace();  }
		
		/*try {
			getscreenshot();
		} catch (IOException e) {			
			e.printStackTrace();}
		*/
}

	
	//This method fetches the serial number for device 
	public void validateSerialNumberUsingJson() throws ParseException {
		
		try {
			JsonDataReader jsonreader=new JsonDataReader();
			List<Devices> devicelist = jsonreader.readJSONData();
			String serialnoFromJson= devicelist.get(deviceindex).getSerialNumber();
			System.out.println("Serial Number from Json: "+serialnoFromJson);			
			String serialNofromUI= StringUtils.substringAfterLast(serialNumber.getText(), ":").trim();
			System.out.println("Serial Number from Json: "+serialNofromUI);
			Assert.assertEquals(serialNofromUI,serialnoFromJson);			
		
		} catch (IOException e) {			
				e.printStackTrace();}
 }
	
public void invalidSerialNumber() throws ParseException {
		
		try {
			JsonDataReader jsonreader=new JsonDataReader();
			List<Devices> devicelist = jsonreader.readJSONData();
			String serialnoFromJson= devicelist.get(deviceindex).getSerialNumber();
			System.out.println("Serial Number from Json: "+serialnoFromJson);			
			String serialNofromUI= StringUtils.substringAfterLast(serialNumber.getText(), ":").trim();
			System.out.println("Serial Number from Json: "+serialNofromUI);
			Assert.assertEquals(serialNofromUI,serialnoFromJson);			
		
		} catch (Exception e) {			
				System.out.println("Invalid Serial Number"); }
 }
	
	// Display events if present or unavailable
	public void verifyNoEventsdata() {

		try {
			Thread.sleep(40);
			System.out.println(textforNoEvent.getText());					
			Assert.assertEquals(textforNoEvent.getText(), "Event Not available");
		} catch (InterruptedException e) {		
			e.getMessage() ;}		
	
	}
	
	public void verifyEvents(int index) {

		try {
			Thread.sleep(40);		
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", EventsTab);
			List<WebElement> Eventtablerow=  EventsTable.findElements(By.tagName("tr"));
			System.out.println(Eventtablerow.size());
			for(int i=0; i<Eventtablerow.size();i++) {		
				JsonDataReader jsonreader= new JsonDataReader();	
				List<Events> Eventslist=jsonreader.readEventJSONData();					
				List<WebElement> EventtableCols= Eventtablerow.get(i).findElements(By.tagName("td"));
				for(int j=0; j<EventtableCols.size();j++) {									
					System.out.println(EventtableCols.get(j).getText() +"---"+Eventslist.get(0).getCommercial_region());
					
					Assert.assertEquals(Eventslist.get(index).getDeviceid(), EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getEvent_type(), EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getDescription(), EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getCommercial_region(), EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getService_region(),EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getError_code(), EventtableCols.get(j).getText());
					Assert.assertEquals(Eventslist.get(index).getTimestamp(), EventtableCols.get(j).getText());
				}
			}
			if(index>0) {
				clickDeviceUsingJson(index);	}				
		}  catch (Exception e) {			
				System.out.println("No Events found for device");
		}		
	
	}

	public void validateTabsinhomepage() {
				
		Assert.assertNotNull(ManageUserslink);
		Assert.assertNotNull(MoreInfolink);
		Assert.assertNotNull(Disconnectlink);
		Assert.assertNotNull(MakeFavlink);
		Assert.assertNotNull(ScheduleInstrumentlink);		
		System.out.println("Following links are validated: \n" +ManageUserslink.getText()+"\n"+MoreInfolink.getText()+"\n"+
		Disconnectlink.getText()+"\n"+MakeFavlink.getText()+"\n"+languagelink.getText() );
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}
	
}
