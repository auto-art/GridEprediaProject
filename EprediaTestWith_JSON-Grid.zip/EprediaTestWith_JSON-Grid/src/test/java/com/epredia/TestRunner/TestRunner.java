/*package com.epredia.TestRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;			


	//@RunWith(Cucumber.class)				
	@CucumberOptions(tags="@JsonTestCase1",	 dryRun=false, 
					 features="resources/Features", glue={"com.epredia.StepDefinition"},
					 plugin = {"pretty:STDOUT",  "json:target/cucumber-reports/TestResults.json",	"html:target/cucumber-reports"},
					 strict = true,
					 monochrome=true)  // for html result
								 						
	
	public class TestRunner  {		

	}*/


