package com.epredia.TestRunner;
/*As we have trigger the tests from xml file of TestNG we can replace the TestRunner file with below code,
 *  as our entry point would be TestNGRunner xml.   	 */
	import java.net.MalformedURLException;
	import java.net.URL;

	import org.openqa.selenium.remote.CapabilityType;
	import org.openqa.selenium.remote.DesiredCapabilities;
	import org.openqa.selenium.remote.RemoteWebDriver;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Parameters;
	import org.testng.annotations.Test;
	import io.cucumber.testng.CucumberOptions;
	import io.cucumber.testng.CucumberFeatureWrapper;
	import io.cucumber.testng.PickleEventWrapper;
	import io.cucumber.testng.TestNGCucumberRunner;

	 
	@CucumberOptions(tags="@PositiveTests",	 dryRun=false, 
			 features="resources/Features", glue={"com.epredia.StepDefinition"},
			 plugin = {"pretty:STDOUT",  "json:target/cucumber-reports/TestResults.json",	"html:target/cucumber-reports"},
			 strict = true,
			 monochrome=true)  // for html result
	
	public class TestGridRunner {			
		private TestNGCucumberRunner testNGCucumberRunner;
		protected RemoteWebDriver remotedriver;
		
 @BeforeClass(alwaysRun = true)
	public void setUpCucumber() {
		    	 testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		 }

 @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
 public  void feature(PickleEventWrapper pickleevent, CucumberFeatureWrapper cucumberFeature) {
             //	testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
				testNGCucumberRunner.provideScenarios();
  }
 
 @DataProvider(parallel=true)
 public Object[][] features() {
    // return testNGCucumberRunner.provideFeatures();    	
 	 return testNGCucumberRunner.provideScenarios();
 }
 
	 //@BeforeMethod(alwaysRun = true)
	 @Parameters(value = { "browser", "version" })
	  public void setUpClass(String browser, String version) throws Exception  { 
		
		 	String gridURL = "http://192.168.1.10:4444/wd/hub";
		 	System.out.println(gridURL);
			DesiredCapabilities capability = new DesiredCapabilities();	  
			   
			   capability.setCapability(CapabilityType.BROWSER_NAME, browser);
	    	   capability.setCapability(CapabilityType.VERSION,version);
	    	   capability.setCapability("build", "Test Epredia App");	    		
	    		capability.setCapability("network", true);
	    		capability.setCapability("video", true);
	    		capability.setCapability("console", true);
	    		capability.setCapability("visual", true);
		        try {
		        	remotedriver = new RemoteWebDriver(new URL(gridURL), capability);
		    		System.out.println(capability);
		    		System.out.println(remotedriver);	
		    		}     
		        catch (MalformedURLException e) {
		            System.out.println("Invalid grid URL");
		            } 
	 }
	 
		     
	 
@AfterClass
 public void tearDown() {	        
	        testNGCucumberRunner.finish();
	    }
}
